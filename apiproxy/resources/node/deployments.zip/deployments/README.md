Deployment files will be placed here as needed.

For example, a deployment to an Amazon account names "aws" will create a aws.zip file in this directory for you to be
able to upload to Elastic Beanstalk.
